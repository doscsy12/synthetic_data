# Modified version of the NetComp package.

The original implementation can be found here: [Github](https://github.com/peterewills/NetComp)